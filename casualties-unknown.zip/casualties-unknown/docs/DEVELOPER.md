# Developer Documentation

## Architecture overview

The mod is server-authoritative: all real state lives in
`PlayerHealthData` (attached to each player via Fabric's data attachment
API), and all real *decisions* (damage distribution, treatment effects,
death) happen on the server. The client only ever holds a read-only cached
copy for rendering (`ClientHealthCache`), refreshed by
`HealthSyncPayload`.

```
components/   Pure data: BodyPart, BleedingLevel, BurnLevel, ShockLevel,
              BodyPartData (one limb's injuries), PlayerHealthData (the
              whole-player aggregate + NBT (de)serialization).
medical/      Game-logic glue: DamageDistributor (which limb(s) a hit
              lands on), InjuryApplier (what statuses that hit causes),
              MedicalItem (the shared press-and-hold/minigame item base
              class), TreatmentTargets (auto-pick / manual-focus target
              resolution).
items/        One class per medical item, each just deciding *what*
              applyTreatment() does -- all the use-duration/minigame/
              networking plumbing is inherited from MedicalItem.
effects/      The systems that run once a second per player: bleeding
              (blood loss), pain, fractures, exhaustion, hydration,
              infection, shock. Each is a small static-method class so
              you can add a new one without touching the others.
events/       Wiring into Fabric/vanilla events: DamageEventHandler
              (redirects vanilla damage into the custom system),
              ServerTickHandler (drives the effects/ systems + network
              sync), PlayerConnectionHandler (join/respawn/disconnect),
              HealthSyncHelper (dirty-flag-based sync coalescing).
network/      CustomPayload records + registration (ModNetworking) for
              the three packets: HealthSyncPayload (S2C), 
              SelectTreatmentTargetPayload (C2S), TreatmentResultPayload
              (C2S, minigame result).
registry/     Item/sound/attachment/creative-tab registration.
config/       ModConfig -- plain JSON file, no extra dependency.
gui/          Client-only Screens: InjuriesScreen (the M-key menu),
              TreatmentMinigameScreen (the timing-bar minigame).
render/       HealthHud -- the custom HUD (bars, condition icons,
              treatment progress bar).
client/       ClientModInitializer + client-only support: the health
              cache, keybinding, client networking, dynamic light
              tracking.
mixin/        The three actual mixins, kept deliberately small -- see
              "Known risk areas" below.
util/         Shared constants (mod id, logger).
```

## Data flow for a typical hit

1. Something damages the player. Vanilla resolves armor/enchantments/
   shield as normal.
2. `DamageEventHandler` (via Fabric's `ServerLivingEntityEvents.AFTER_DAMAGE`)
   receives the *final* mitigated amount.
3. `DamageDistributor.categorize()` + `.distribute()` decide which body
   part(s) take how much of that amount, based on the damage source type
   (explosion/fall/fire/projectile/melee/generic).
4. `InjuryApplier.apply()` turns that per-part damage into actual status
   changes (bleeding, fractures, burns, bruises, lacerations, gunshot
   wounds, internal bleeding, pain).
5. The player's *vanilla* health is immediately topped back up to max, so
   the (hidden) hearts never actually change and vanilla never ends the
   game on its own.
6. `HealthSyncHelper.markDirty()` flags the player; `ServerTickHandler`
   flushes one `HealthSyncPayload` per dirty player per tick.
7. If `PlayerHealthData.isDead()` (head or torso destroyed, or blood
   volume hits 0), `player.kill(...)` triggers a real vanilla death.

## Data flow for a treatment item

**Simple items** (Painkillers, Orange Juice, Water Bottle, Disinfectant,
Tourniquet, Blood Bag, Saline IV, Antibiotics, Burn Cream, Syringe,
Medical Scissors): hold right-click for the item's use duration -> vanilla
calls `finishUsing` on the server -> `MedicalItem.applyTreatment(player,
1.0f)` runs directly -> item is consumed (unless `isConsumable()` is
false, e.g. Scissors).

**Minigame items** (Bandage, Military Bandage, Splint, Medkit): hold
right-click -> on the *client*, `finishUsing` opens
`TreatmentMinigameScreen` via `MedicalItem.MINIGAME_LAUNCHER` -> player
resolves the timing bar -> client sends `TreatmentResultPayload(itemId,
quality)` -> `ModNetworking` re-validates the player actually holds a
matching item (a modified client can't fake a perfect score) -> calls
`applyTreatment(player, quality)` -> consumes the item.

## Extension points (things deliberately left simple to expand)

- **More minigame types.** `TreatmentMinigameScreen` implements the
  "timing bar" style only. To add "moving cursor", "precision click", or
  "pattern memory": create a new `Screen` subclass following the same
  shape (resolve a 0-1 `quality` float, call
  `ClientNetworking.sendTreatmentResult(itemId, quality)`, close), and
  have `MedicalItem.MINIGAME_LAUNCHER` (or a per-item override) pick which
  screen to open.
- **Manual body-part targeting beyond "Focus".** `TreatmentTargets`
  already supports a per-player manual override; the Injuries Menu's
  Focus buttons use it. You could extend this with a clear/auto-target
  button, or expose it as a HUD hotkey.
- **Durability on tools.** Medical Scissors and Medical Gloves currently
  never take durability damage (`isConsumable() == false` just skips
  consumption entirely). Give them a `maxDamage` in `ModItems` and call
  `stack.damage(...)` in their `applyTreatment`/tick logic if you want
  wear-and-tear.
- **Environmental temperature.** `InfectionSystem` currently only drives
  temperature up (fever) and lets it drift back down -- there's no biome/
  weather/wetness contribution yet. A `TemperatureSystem` following the
  same one-per-second static-class pattern as the others would slot in
  cleanly.
- **Data generation.** Recipes/models/lang are hand-written JSON right
  now. If you'd rather generate them, Fabric's data generation API can
  take over `data/` and `assets/` -- see
  https://docs.fabricmc.net/develop/data-generation/setup.
- **In-game config screen.** `ModConfig` is a plain public-field POJO
  specifically so a Cloth Config (or similar) screen could bind to it
  directly later without changing the config format.
- **Interrupting an in-progress minigame.** "Interrupt if damaged"
  currently cancels the *hold* phase cleanly (`DamageEventHandler` calls
  `player.stopUsingItem()`), but for minigame items the server's own use
  timer finishes (and thus stops tracking "in use") slightly before the
  client's minigame screen actually concludes, so damage taken *during*
  the minigame's own few seconds doesn't auto-close it. Closing it too
  would need one more small S2C payload (e.g. `CancelMinigamePayload`)
  sent from `DamageEventHandler` when the active item is mid-minigame.

## Known risk areas / if the build doesn't compile or crashes on launch

This project was written without access to a live Fabric/Minecraft
toolchain (no internet in the sandbox it was built in), so nothing here
has actually been compiled or run. Everything is written to match the
real 1.21.1 Yarn-mapped API as closely as this author's knowledge allows,
but a few specific spots are more likely than the rest to need a small
correction:

1. **`ModAttachmentTypes`** -- the Fabric Data Attachment API
   (`net.fabricmc.fabric.api.attachment.v1`) is one of the newer parts of
   Fabric API. If `AttachmentRegistry.create(...)` or the builder methods
   (`initializer`, `persistent`, `copyOnDeath`) don't match, check the
   current Fabric API javadocs/source for `AttachmentRegistry` and
   `AttachmentType.Builder` and adjust the chain in this one file --
   nothing else depends on the internal shape of this API, only on
   `PlayerHealthData` going in and out.
2. **`DamageEventHandler`** -- built around
   `ServerLivingEntityEvents.AFTER_DAMAGE`. If the lambda's parameter list
   doesn't match, check `net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents`
   for the current signature (it should still give you the entity, the
   `DamageSource`, and the final mitigated damage amount in some form).
3. **`InGameHudMixin`** -- targets `InGameHud#renderHealthBar` and
   `#renderFood` by name. These private method names/signatures have
   shifted before across versions. Run `./gradlew genSources`, open the
   generated `InGameHud.java`, and match the method names/parameter types
   used here to whatever you find.
4. **`ClientWorldDynamicLightMixin` / `DynamicLightManager`** -- dynamic
   lighting works by boosting `World#getLightLevel(LightType, BlockPos)`
   and nudging the light engine with `checkBlock`. This is the most
   version-fragile *category* of change in all of Minecraft's renderer.
   If lights don't appear, this is the first place to check; the
   technique itself (used by mods like LambDynamicLights) is sound even
   if an exact method name here has moved.
5. **`ModItems.PLACEHOLDER_SONG` / jukebox song data file** -- the
   data-driven jukebox song system is a relatively recent (1.21) rework
   of how music discs work. If `Item.Settings#jukeboxPlayable(...)`
   doesn't match, check `net.minecraft.item.JukeboxSong` and how vanilla's
   own `Items.java` registers `MUSIC_DISC_13` etc. for the current
   pattern, and mirror it.
6. **Everything else** (items, effects, GUI, config, networking payload
   records) uses stable, long-standing Minecraft/Fabric APIs (basic
   `Item`/`ItemStack`/`Screen`/`DrawContext` methods, `PacketCodec`
   records, Gson) that are very unlikely to have shifted.

None of these are deep design problems -- they're all "the method
changed its exact name/signature since this was written" risks, which is
the normal cost of hand-writing Minecraft mod code without a live
toolchain to check against.
