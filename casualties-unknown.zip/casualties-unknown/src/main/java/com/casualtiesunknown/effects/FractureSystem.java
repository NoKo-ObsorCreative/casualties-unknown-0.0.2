package com.casualtiesunknown.effects;

import com.casualtiesunknown.components.PlayerHealthData;
import com.casualtiesunknown.config.ModConfig;

import net.minecraft.server.network.ServerPlayerEntity;

/**
 * Broken arm: slower mining, less attack damage.
 * Broken leg: limping (slowness), cannot sprint.
 */
public final class FractureSystem {

	private FractureSystem() {
	}

	public static void tick(ServerPlayerEntity player, PlayerHealthData data, ModConfig config) {
		if (!config.enableLimbDamage) {
			return;
		}

		if (data.isArmFractured()) {
			StatusEffectApplier.applyMiningFatigue(player, 1);
			StatusEffectApplier.applyWeakness(player, 1);
		}

		if (data.isLegFractured()) {
			StatusEffectApplier.applySlowness(player, 1);
			if (player.isSprinting()) {
				player.setSprinting(false);
			}
		}
	}
}
