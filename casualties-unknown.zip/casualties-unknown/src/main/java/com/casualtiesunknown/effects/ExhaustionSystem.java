package com.casualtiesunknown.effects;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import com.casualtiesunknown.components.PlayerHealthData;
import com.casualtiesunknown.config.ModConfig;

import net.minecraft.server.network.ServerPlayerEntity;

/**
 * Exhaustion is deliberately separate from vanilla hunger (which this mod
 * otherwise leaves alone, aside from disabling the natural-regen tie-in --
 * see PlayerEntityTickMixin). It rises from running, jumping, combat and
 * bleeding, and recovers slowly at rest.
 */
public final class ExhaustionSystem {

	private static final Map<UUID, Boolean> WAS_ON_GROUND = new ConcurrentHashMap<>();

	private ExhaustionSystem() {
	}

	public static void tick(ServerPlayerEntity player, PlayerHealthData data, ModConfig config) {
		float multiplier = config.exhaustionRateMultiplier;

		boolean onGround = player.isOnGround();
		boolean wasOnGround = WAS_ON_GROUND.getOrDefault(player.getUuid(), true);
		if (wasOnGround && !onGround && player.getVelocity().y > 0.1) {
			onJump(data, config);
		}
		WAS_ON_GROUND.put(player.getUuid(), onGround);

		if (player.isSprinting()) {
			data.addExhaustion(2.0f * multiplier);
		} else if (player.getVelocity().horizontalLengthSquared() > 0.003) {
			data.addExhaustion(0.3f * multiplier);
		} else {
			data.addExhaustion(-1.5f * multiplier);
		}

		if (data.isBleedingAnywhere()) {
			data.addExhaustion(0.5f * multiplier);
		}

		applyFeedback(player, data);
	}

	public static void onJump(PlayerHealthData data, ModConfig config) {
		data.addExhaustion(1.0f * config.exhaustionRateMultiplier);
	}

	public static void onCombatAction(PlayerHealthData data, ModConfig config) {
		data.addExhaustion(1.5f * config.exhaustionRateMultiplier);
	}

	private static void applyFeedback(ServerPlayerEntity player, PlayerHealthData data) {
		float exhaustion = data.getExhaustion();
		if (exhaustion > 80) {
			StatusEffectApplier.applySlowness(player, 1);
			if (player.isSprinting()) {
				player.setSprinting(false);
			}
		} else if (exhaustion > 50) {
			StatusEffectApplier.applySlowness(player, 0);
		}
	}

	public static void forgetPlayer(UUID uuid) {
		WAS_ON_GROUND.remove(uuid);
	}
}
