package com.casualtiesunknown.effects;

import com.casualtiesunknown.components.PlayerHealthData;
import com.casualtiesunknown.config.ModConfig;

import net.minecraft.server.network.ServerPlayerEntity;

/** Thirst, drained slowly over time and restored by Water Bottle / Orange Juice / Blood Bag / Saline IV. */
public final class HydrationSystem {

	private static final float DRAIN_PER_SECOND = 0.03f;

	private HydrationSystem() {
	}

	public static void tick(ServerPlayerEntity player, PlayerHealthData data, ModConfig config) {
		data.addHydration(-DRAIN_PER_SECOND);

		if (data.getHydration() < 20) {
			// Dehydration compounds exhaustion and mild weakness.
			data.addExhaustion(0.5f * config.exhaustionRateMultiplier);
			StatusEffectApplier.applyWeakness(player, 0);
		}
	}
}
