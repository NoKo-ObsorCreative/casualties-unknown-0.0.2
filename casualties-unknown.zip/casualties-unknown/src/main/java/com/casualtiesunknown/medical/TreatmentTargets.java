package com.casualtiesunknown.medical;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import com.casualtiesunknown.components.BleedingLevel;
import com.casualtiesunknown.components.BodyPart;
import com.casualtiesunknown.components.PlayerHealthData;

/**
 * Tracks which body part each player has manually "focused" via the Injuries
 * Menu's Focus buttons. Intentionally not persisted -- it resets to
 * auto-target on rejoin, which is the friendlier default.
 */
public final class TreatmentTargets {

	private static final Map<UUID, BodyPart> FOCUSED = new ConcurrentHashMap<>();

	private TreatmentTargets() {
	}

	public static void setFocus(UUID player, BodyPart part) {
		FOCUSED.put(player, part);
	}

	public static void clearFocus(UUID player) {
		FOCUSED.remove(player);
	}

	/**
	 * Resolves the actual part a treatment item should target: the player's
	 * manual focus if they set one, otherwise whichever part best matches
	 * {@code selector}'s own auto-pick logic.
	 */
	public static BodyPart resolve(UUID player, PlayerHealthData data, java.util.function.Function<PlayerHealthData, BodyPart> autoSelector) {
		BodyPart focused = FOCUSED.get(player);
		if (focused != null) {
			return focused;
		}
		return autoSelector.apply(data);
	}

	/** Default auto-selector: the most-bleeding part, tie-broken by lowest HP fraction. */
	public static BodyPart autoPickBleeding(PlayerHealthData data) {
		BodyPart best = BodyPart.TORSO;
		BleedingLevel bestLevel = BleedingLevel.NONE;
		float bestFraction = Float.MAX_VALUE;
		for (BodyPart part : BodyPart.values()) {
			var partData = data.part(part);
			BleedingLevel level = partData.getBleeding();
			float fraction = partData.getHpFraction();
			if (level.ordinal() > bestLevel.ordinal() || (level.ordinal() == bestLevel.ordinal() && fraction < bestFraction)) {
				best = part;
				bestLevel = level;
				bestFraction = fraction;
			}
		}
		return best;
	}

	/** Auto-selector for splints: the first fractured limb found, preferring legs. */
	public static BodyPart autoPickFracture(PlayerHealthData data) {
		for (BodyPart part : new BodyPart[] {BodyPart.LEFT_LEG, BodyPart.RIGHT_LEG, BodyPart.LEFT_ARM, BodyPart.RIGHT_ARM}) {
			if (data.part(part).isFractured()) {
				return part;
			}
		}
		return BodyPart.LEFT_LEG;
	}

	/** Auto-selector for burn cream: the most severely burned part. */
	public static BodyPart autoPickBurn(PlayerHealthData data) {
		BodyPart best = BodyPart.TORSO;
		int bestOrdinal = -1;
		for (BodyPart part : BodyPart.values()) {
			int ordinal = data.part(part).getBurn().ordinal();
			if (ordinal > bestOrdinal) {
				best = part;
				bestOrdinal = ordinal;
			}
		}
		return best;
	}

	/** Auto-selector for the lowest-HP-fraction part overall (used by the Medkit). */
	public static BodyPart autoPickWorstOverall(PlayerHealthData data) {
		BodyPart best = BodyPart.TORSO;
		float bestFraction = Float.MAX_VALUE;
		for (BodyPart part : BodyPart.values()) {
			float fraction = data.part(part).getHpFraction();
			if (fraction < bestFraction) {
				best = part;
				bestFraction = fraction;
			}
		}
		return best;
	}
}
