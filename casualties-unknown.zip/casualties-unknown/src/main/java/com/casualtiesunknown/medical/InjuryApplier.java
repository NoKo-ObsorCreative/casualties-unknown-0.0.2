package com.casualtiesunknown.medical;

import java.util.Map;
import java.util.random.RandomGenerator;

import com.casualtiesunknown.components.BodyPart;
import com.casualtiesunknown.components.BodyPartData;
import com.casualtiesunknown.components.BurnLevel;
import com.casualtiesunknown.components.PlayerHealthData;

/**
 * Applies the actual injury-status side effects (bleeding, fractures, burns,
 * bruises, lacerations, gunshot wounds, internal bleeding, pain) once
 * {@link DamageDistributor} has decided how much raw damage lands on each
 * body part.
 */
public final class InjuryApplier {

	private InjuryApplier() {
	}

	public static void apply(PlayerHealthData healthData, DamageDistributor.Category category,
			Map<BodyPart, Float> distribution, RandomGenerator random) {

		for (Map.Entry<BodyPart, Float> entry : distribution.entrySet()) {
			BodyPart part = entry.getKey();
			float amount = entry.getValue();
			if (amount <= 0) {
				continue;
			}
			BodyPartData data = healthData.part(part);
			data.damage(amount);
			data.addPain(amount * 0.6f);

			// A wound that's already bleeding gets worse under repeat trauma;
			// a fresh moderate+ hit has a chance to start bleeding.
			if (amount >= 4.0f || data.getBleeding().isBleeding()) {
				float chance = category == DamageDistributor.Category.PROJECTILE ? 0.85f : 0.5f;
				if (random.nextFloat() < chance) {
					data.worsenBleeding();
				}
			}

			switch (category) {
				case FALL -> {
					if (part.isLeg() && amount > 6.0f && random.nextFloat() < 0.4f) {
						data.setFractured(true);
					}
					data.setBruised(true);
				}
				case EXPLOSION -> {
					data.setLaceration(true);
					if (part == BodyPart.TORSO && random.nextFloat() < 0.25f) {
						data.setInternalBleeding(true);
					}
					if (part.isArm() || part.isLeg()) {
						if (amount > 10.0f && random.nextFloat() < 0.3f) {
							data.setFractured(true);
						}
					}
				}
				case FIRE -> {
					BurnLevel newLevel = data.getBurn().worsen();
					data.setBurn(newLevel);
				}
				case PROJECTILE -> {
					// Piercing wounds (arrows, tridents, other projectiles) are modeled
					// as gunshot-wound-equivalent penetrating injuries.
					data.addGunshotWound();
					data.setLaceration(true);
				}
				case MELEE -> data.setBruised(true);
				case GENERIC -> {
					// no extra status, just HP + pain + possible bleeding handled above
				}
			}
		}
	}
}
