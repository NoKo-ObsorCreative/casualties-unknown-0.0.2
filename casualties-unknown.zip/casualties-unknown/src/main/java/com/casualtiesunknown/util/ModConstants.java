package com.casualtiesunknown.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.minecraft.util.Identifier;

/** Shared constants used across the mod. */
public final class ModConstants {
	public static final String MOD_ID = "casualtiesunknown";
	public static final Logger LOGGER = LoggerFactory.getLogger("Casualties Unknown");

	private ModConstants() {
	}

	public static Identifier id(String path) {
		return Identifier.of(MOD_ID, path);
	}
}
