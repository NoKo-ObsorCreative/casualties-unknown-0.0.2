package com.casualtiesunknown.client.light;

import com.casualtiesunknown.config.ModConfig;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.LightType;
import net.minecraft.world.World;

/**
 * Client-only tracker for the "dynamic lights" feature: holding a Torch,
 * Lantern, Soul Torch, Soul Lantern or Redstone Torch in either hand
 * illuminates the area around the player without placing any real light
 * source block.
 *
 * <p><b>How it works:</b> every client tick we note the player's current
 * block position and the brightest held light-emitting item. The actual
 * brightening happens in {@link com.casualtiesunknown.mixin.client.ClientWorldDynamicLightMixin},
 * which asks {@link #getExtraLight(BlockPos)} for a bonus light value at
 * each queried position and takes the max with the vanilla value. This
 * mirrors the technique used by dedicated dynamic-light mods (e.g.
 * LambDynamicLights): no block is ever placed or changed, so the world is
 * never permanently modified, but we do need to nudge the light engine
 * (via {@code checkBlock}) at both the old and new position whenever the
 * source moves so brightness updates smoothly and reverts immediately when
 * the item is switched away.
 *
 * <p>This is the most version-fragile part of the whole mod -- light-engine
 * internals change more often than almost anything else in Minecraft's
 * renderer. If lights don't appear, double check that
 * {@code ClientWorldDynamicLightMixin} is actually applying (see its
 * class comment for troubleshooting).
 */
public final class DynamicLightManager {

	private static BlockPos currentPos;
	private static int currentLuminance;
	private static final int UPDATE_RADIUS = 2;

	private DynamicLightManager() {
	}

	public static void tick(ClientPlayerEntity player) {
		if (!ModConfig.get().enableDynamicLights) {
			if (currentPos != null) {
				clear(player.getWorld());
			}
			return;
		}

		int luminance = Math.max(
				luminanceOf(player.getMainHandStack().getItem()),
				luminanceOf(player.getOffHandStack().getItem())
		);

		BlockPos newPos = player.getBlockPos();

		boolean changed = luminance != currentLuminance || !newPos.equals(currentPos);
		if (!changed) {
			return;
		}

		BlockPos oldPos = currentPos;
		currentPos = luminance > 0 ? newPos : null;
		currentLuminance = luminance;

		World world = player.getWorld();
		if (oldPos != null) {
			refreshAround(world, oldPos);
		}
		if (currentPos != null) {
			refreshAround(world, currentPos);
		}
	}

	private static void clear(World world) {
		BlockPos oldPos = currentPos;
		currentPos = null;
		currentLuminance = 0;
		if (oldPos != null) {
			refreshAround(world, oldPos);
		}
	}

	private static void refreshAround(World world, BlockPos center) {
		for (BlockPos pos : BlockPos.iterate(
				center.add(-UPDATE_RADIUS, -UPDATE_RADIUS, -UPDATE_RADIUS),
				center.add(UPDATE_RADIUS, UPDATE_RADIUS, UPDATE_RADIUS))) {
			world.getLightingProvider().checkBlock(pos.toImmutable());
		}
	}

	/** Returns the extra (block) light this system contributes at the given position, 0 if none. */
	public static int getExtraLight(BlockPos pos) {
		if (currentPos == null || currentLuminance <= 0) {
			return 0;
		}
		int distance = manhattanDistance(pos, currentPos);
		return Math.max(0, currentLuminance - distance);
	}

	private static int manhattanDistance(BlockPos a, BlockPos b) {
		return Math.abs(a.getX() - b.getX()) + Math.abs(a.getY() - b.getY()) + Math.abs(a.getZ() - b.getZ());
	}

	private static int luminanceOf(Item item) {
		if (item == Items.TORCH) {
			return 14;
		} else if (item == Items.LANTERN) {
			return 15;
		} else if (item == Items.SOUL_TORCH) {
			return 10;
		} else if (item == Items.SOUL_LANTERN) {
			return 10;
		} else if (item == Items.REDSTONE_TORCH) {
			return 7;
		}
		return 0;
	}
}
