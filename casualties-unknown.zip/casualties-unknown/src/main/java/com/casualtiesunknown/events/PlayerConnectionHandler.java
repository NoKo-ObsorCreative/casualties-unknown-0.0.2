package com.casualtiesunknown.events;

import com.casualtiesunknown.components.PlayerHealthData;
import com.casualtiesunknown.config.ModConfig;
import com.casualtiesunknown.effects.ExhaustionSystem;
import com.casualtiesunknown.registry.ModAttachmentTypes;

import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * Wires up join / respawn / disconnect so the attachment, vanilla max
 * health and initial network sync are all set up (and torn down) at the
 * right times.
 */
public final class PlayerConnectionHandler {

	/**
	 * Vanilla max health is set high and kept topped up (see ServerTickHandler
	 * and DamageEventHandler) so hidden hearts never hit 0 on their own --
	 * our own PlayerHealthData is the real source of truth for death.
	 */
	public static final double SHADOW_MAX_HEALTH = 400.0;

	private PlayerConnectionHandler() {
	}

	public static void register() {
		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
			ServerPlayerEntity player = handler.getPlayer();
			applyShadowMaxHealth(player);
			PlayerHealthData data = player.getAttachedOrCreate(ModAttachmentTypes.HEALTH_DATA);
			HealthSyncHelper.sendFullSync(player, data);
		});

		ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
			ExhaustionSystem.forgetPlayer(handler.getPlayer().getUuid());
		});

		// Respawn after death: apply the resetHealthOnDeath config, then re-sync.
		// (This runs on respawn rather than on death itself since that's when the
		// new player entity -- and its fresh attachment copy -- actually exists.)
		ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
			applyShadowMaxHealth(newPlayer);
			PlayerHealthData data = newPlayer.getAttachedOrCreate(ModAttachmentTypes.HEALTH_DATA);
			if (ModConfig.get().resetHealthOnDeath) {
				data.resetToFull();
			}
			HealthSyncHelper.sendFullSync(newPlayer, data);
		});
	}

	private static void applyShadowMaxHealth(ServerPlayerEntity player) {
		var attribute = player.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
		if (attribute != null && attribute.getBaseValue() != SHADOW_MAX_HEALTH) {
			attribute.setBaseValue(SHADOW_MAX_HEALTH);
		}
		player.setHealth(player.getMaxHealth());
	}
}
