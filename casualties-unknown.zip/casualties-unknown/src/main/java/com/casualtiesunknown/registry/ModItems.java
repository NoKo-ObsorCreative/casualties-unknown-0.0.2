package com.casualtiesunknown.registry;

import java.util.function.Function;

import com.casualtiesunknown.items.AntibioticsItem;
import com.casualtiesunknown.items.BandageItem;
import com.casualtiesunknown.items.BloodBagItem;
import com.casualtiesunknown.items.BurnCreamItem;
import com.casualtiesunknown.items.DisinfectantItem;
import com.casualtiesunknown.items.MedicalGlovesItem;
import com.casualtiesunknown.items.MedicalScissorsItem;
import com.casualtiesunknown.items.MedkitItem;
import com.casualtiesunknown.items.MilitaryBandageItem;
import com.casualtiesunknown.items.OrangeJuiceItem;
import com.casualtiesunknown.items.PainkillerItem;
import com.casualtiesunknown.items.SalineIvItem;
import com.casualtiesunknown.items.SplintItem;
import com.casualtiesunknown.items.SyringeItem;
import com.casualtiesunknown.items.TourniquetItem;
import com.casualtiesunknown.items.WaterBottleItem;
import com.casualtiesunknown.util.ModConstants;

import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;

/**
 * Registers every item added by this mod. All of them currently use the
 * vanilla Potato item model/texture as a placeholder -- see
 * docs/TEXTURES_AND_MODELS.md for exactly where to drop in real art.
 */
public final class ModItems {

	public static final Item BANDAGE =
			register("bandage", BandageItem::new, new Item.Settings().maxCount(16));
	public static final Item MILITARY_BANDAGE =
			register("military_bandage", MilitaryBandageItem::new, new Item.Settings().maxCount(16));
	public static final Item SPLINT =
			register("splint", SplintItem::new, new Item.Settings().maxCount(8));
	public static final Item PAINKILLERS =
			register("painkillers", PainkillerItem::new, new Item.Settings().maxCount(16));
	public static final Item DISINFECTANT =
			register("disinfectant", DisinfectantItem::new, new Item.Settings().maxCount(16));
	public static final Item TOURNIQUET =
			register("tourniquet", TourniquetItem::new, new Item.Settings().maxCount(8));
	public static final Item BLOOD_BAG =
			register("blood_bag", BloodBagItem::new, new Item.Settings().maxCount(4));
	public static final Item SALINE_IV =
			register("saline_iv", SalineIvItem::new, new Item.Settings().maxCount(4));
	public static final Item ORANGE_JUICE =
			register("orange_juice", OrangeJuiceItem::new, new Item.Settings().maxCount(16));
	public static final Item WATER_BOTTLE =
			register("water_bottle", WaterBottleItem::new, new Item.Settings().maxCount(16));
	public static final Item ANTIBIOTICS =
			register("antibiotics", AntibioticsItem::new, new Item.Settings().maxCount(16));
	public static final Item BURN_CREAM =
			register("burn_cream", BurnCreamItem::new, new Item.Settings().maxCount(16));
	public static final Item MEDKIT =
			register("medkit", MedkitItem::new, new Item.Settings().maxCount(1));
	public static final Item MEDICAL_SCISSORS =
			register("medical_scissors", MedicalScissorsItem::new, new Item.Settings().maxCount(1));
	public static final Item MEDICAL_GLOVES =
			register("medical_gloves", MedicalGlovesItem::new, new Item.Settings().maxCount(1));
	public static final Item SYRINGE =
			register("syringe", SyringeItem::new, new Item.Settings().maxCount(16));

	/**
	 * The placeholder music disc. Uses Minecraft's data-driven jukebox song
	 * system (introduced in 1.21): the actual song metadata (sound event,
	 * length, comparator output) lives in
	 * data/casualtiesunknown/jukebox_song/placeholder.json, referenced here
	 * by registry key. See docs/TEXTURES_AND_MODELS.md for where the audio
	 * file itself (down1.ogg) needs to go.
	 */
	public static final RegistryKey<net.minecraft.item.JukeboxSong> PLACEHOLDER_SONG =
			RegistryKey.of(RegistryKeys.JUKEBOX_SONG, ModConstants.id("placeholder"));

	public static final Item MUSIC_DISC_PLACEHOLDER = register("music_disc_placeholder", Item::new,
			new Item.Settings().maxCount(1).jukeboxPlayable(PLACEHOLDER_SONG));

	private ModItems() {
	}

	private static Item register(String path, Function<Item.Settings, Item> factory, Item.Settings settings) {
		Identifier id = ModConstants.id(path);
		RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, id);
		Item item = factory.apply(settings.registryKey(key));
		return Registry.register(Registries.ITEM, key, item);
	}

	public static void register() {
		ModConstants.LOGGER.debug("Registered Casualties Unknown items");
	}
}
