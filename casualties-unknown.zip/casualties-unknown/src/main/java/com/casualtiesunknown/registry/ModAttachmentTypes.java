package com.casualtiesunknown.registry;

import com.casualtiesunknown.components.PlayerHealthData;
import com.casualtiesunknown.util.ModConstants;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;

import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtOps;

/**
 * Registers the {@link PlayerHealthData} attachment. Fabric's attachment API
 * (net.fabricmc.fabric.api.attachment.v1) handles persistence to the
 * player's NBT automatically once {@code .persistent(codec)} is set, which
 * covers the "must survive death/dimension change/logout/server restart"
 * requirement without any custom save code.
 *
 * <p>Death persistence is additionally configurable: see
 * {@link com.casualtiesunknown.events.PlayerConnectionHandler} for how the
 * "reset on death" config option is applied on respawn.
 *
 * <p><b>Known risk:</b> the attachment API's builder methods
 * ({@code initializer}, {@code persistent}, {@code copyOnDeath}) are one of
 * the newer parts of Fabric API and their exact names have shifted before.
 * If this file fails to compile, check the current signature of
 * {@code AttachmentRegistry.Builder} in whatever Fabric API version Gradle
 * resolves and adjust the builder chain below to match.
 */
public final class ModAttachmentTypes {

	/**
	 * NbtCompound doesn't ship a ready-made Codec in Yarn 1.21.1, so we adapt
	 * one here via NbtOps, going through PlayerHealthData's own NBT (de)serialization.
	 */
	public static final Codec<PlayerHealthData> HEALTH_DATA_CODEC = Codec.PASSTHROUGH.comapFlatMap(
			dynamic -> {
				NbtCompound nbt = (NbtCompound) dynamic.convert(NbtOps.INSTANCE).getValue();
				try {
					return DataResult.success(PlayerHealthData.fromNbt(nbt));
				} catch (Exception e) {
					return DataResult.error(() -> "Failed to parse Casualties Unknown health data: " + e);
				}
			},
			data -> new com.mojang.serialization.Dynamic<>(NbtOps.INSTANCE, data.toNbt())
	);

	public static final AttachmentType<PlayerHealthData> HEALTH_DATA = AttachmentRegistry.create(
			ModConstants.id("health_data"),
			builder -> builder
					.initializer(PlayerHealthData::createDefault)
					.persistent(HEALTH_DATA_CODEC)
					.copyOnDeath()
	);

	private ModAttachmentTypes() {
	}

	public static void register() {
		// Referencing HEALTH_DATA triggers static init / registration; nothing else needed here.
		ModConstants.LOGGER.debug("Registered Casualties Unknown attachment types");
	}
}
