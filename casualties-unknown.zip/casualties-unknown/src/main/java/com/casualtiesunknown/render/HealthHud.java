package com.casualtiesunknown.render;

import com.casualtiesunknown.client.ClientHealthCache;
import com.casualtiesunknown.components.PlayerHealthData;
import com.casualtiesunknown.config.ModConfig;
import com.casualtiesunknown.medical.MedicalItem;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

/**
 * Draws the entire replacement HUD: Blood / Pain / Exhaustion / Hydration /
 * Temperature bars, a row of condition icons (bleeding, fracture, infection,
 * pain, shock), and -- while holding right-click on a medical item -- a
 * treatment progress bar. Everything here is drawn procedurally (flat
 * colored bars and text) rather than depending on custom GUI textures, so
 * the HUD is fully functional even before any art is added; see
 * docs/TEXTURES_AND_MODELS.md if you'd like to reskin it with real icon
 * textures from {@code assets/casualtiesunknown/textures/gui/}.
 */
public final class HealthHud {

	private static final int BAR_WIDTH = 90;
	private static final int BAR_HEIGHT = 6;
	private static final int MARGIN = 8;

	private HealthHud() {
	}

	public static void register() {
		HudRenderCallback.EVENT.register(HealthHud::render);
	}

	private static void render(DrawContext context, RenderTickCounter tickCounter) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.player == null || client.options.hudHidden) {
			return;
		}
		if (client.currentScreen != null) {
			return;
		}

		PlayerHealthData data = ClientHealthCache.get();
		ModConfig config = ModConfig.get();

		int[] origin = resolveOrigin(context, config.hudPosition);
		int x = origin[0];
		int y = origin[1];
		int direction = origin[2]; // +1 draws downward from y, -1 draws upward

		int lineStep = (BAR_HEIGHT + 3) * direction;

		y = drawBar(context, x, y, "Blood", data.getBloodFraction(), 0xFFCC2E2E);
		y += lineStep;
		y = drawBar(context, x, y, "Pain", data.getGlobalPain() / 100f, 0xFFCC8A2E);
		y += lineStep;
		y = drawBar(context, x, y, "Exhaustion", data.getExhaustion() / 100f, 0xFF8A8A2E);
		y += lineStep;
		y = drawBar(context, x, y, "Hydration", data.getHydration() / 100f, 0xFF2E8ACC);
		y += lineStep;
		float tempFraction = clamp((data.getTemperatureC() - 34f) / (41f - 34f));
		y = drawBar(context, x, y, "Temp", tempFraction, 0xFFCC2EA0);
		y += lineStep + 2 * direction;

		drawConditionIcons(context, x, y, data);

		drawTreatmentProgress(context, client);
	}

	private static int[] resolveOrigin(DrawContext context, String position) {
		int w = context.getScaledWindowWidth();
		int h = context.getScaledWindowHeight();
		return switch (position) {
			case "TOP_RIGHT" -> new int[] {w - MARGIN - BAR_WIDTH, MARGIN + 10, 1};
			case "BOTTOM_LEFT" -> new int[] {MARGIN, h - MARGIN - 80, 1};
			case "BOTTOM_RIGHT" -> new int[] {w - MARGIN - BAR_WIDTH, h - MARGIN - 80, 1};
			default -> new int[] {MARGIN, MARGIN + 10, 1}; // TOP_LEFT
		};
	}

	private static int drawBar(DrawContext context, int x, int y, String label, float fraction, int color) {
		fraction = clamp(fraction);
		context.fill(x, y, x + BAR_WIDTH, y + BAR_HEIGHT, 0x99000000);
		int filled = Math.round(BAR_WIDTH * fraction);
		if (filled > 0) {
			context.fill(x, y, x + filled, y + BAR_HEIGHT, color);
		}
		context.drawTextWithShadow(MinecraftClient.getInstance().textRenderer, Text.literal(label),
				x + BAR_WIDTH + 4, y - 1, 0xFFFFFF);
		return y;
	}

	private static void drawConditionIcons(DrawContext context, int x, int y, PlayerHealthData data) {
		int iconSize = 8;
		int spacing = 11;
		int i = 0;

		if (data.isBleedingAnywhere()) {
			context.fill(x + i * spacing, y, x + i * spacing + iconSize, y + iconSize, 0xFFB02020);
			i++;
		}
		if (data.isAnyFractured()) {
			context.fill(x + i * spacing, y, x + i * spacing + iconSize, y + iconSize, 0xFFC8C8C8);
			i++;
		}
		if (data.isAnyInfected()) {
			context.fill(x + i * spacing, y, x + i * spacing + iconSize, y + iconSize, 0xFF60C860);
			i++;
		}
		if (data.getGlobalPain() > 50) {
			context.fill(x + i * spacing, y, x + i * spacing + iconSize, y + iconSize, 0xFFE0A030);
			i++;
		}
		if (data.getShock().isInShock()) {
			context.fill(x + i * spacing, y, x + i * spacing + iconSize, y + iconSize, 0xFF9060E0);
			i++;
		}
	}

	private static void drawTreatmentProgress(DrawContext context, MinecraftClient client) {
		if (client.player == null || !client.player.isUsingItem()) {
			return;
		}
		ItemStack activeStack = client.player.getActiveItem();
		if (!(activeStack.getItem() instanceof MedicalItem)) {
			return;
		}

		int maxUseTime = activeStack.getMaxUseTime(client.player);
		if (maxUseTime <= 0) {
			return;
		}
		int ticksLeft = client.player.getItemUseTimeLeft();
		float progress = clamp(1.0f - (ticksLeft / (float) maxUseTime));

		int w = context.getScaledWindowWidth();
		int h = context.getScaledWindowHeight();
		int barWidth = 140;
		int barHeight = 8;
		int barX = w / 2 - barWidth / 2;
		int barY = h / 2 + 30;

		context.fill(barX - 1, barY - 1, barX + barWidth + 1, barY + barHeight + 1, 0xFF000000);
		context.fill(barX, barY, barX + barWidth, barY + barHeight, 0x99202225);
		context.fill(barX, barY, barX + Math.round(barWidth * progress), barY + barHeight, 0xFF7CD98A);
	}

	private static float clamp(float value) {
		return Math.max(0f, Math.min(1f, value));
	}
}
