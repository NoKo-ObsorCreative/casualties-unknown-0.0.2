package com.casualtiesunknown.components;

import net.minecraft.nbt.NbtCompound;

/**
 * Mutable injury state for a single {@link BodyPart}. Instances live inside
 * {@link PlayerHealthData}, one per body part, and are synced to the owning
 * client whenever they change (see PlayerHealthData#writeSyncNbt).
 */
public final class BodyPartData {

	private float currentHp;
	private float maxHp;
	private BleedingLevel bleeding = BleedingLevel.NONE;
	private boolean fractured;
	/** 0-100 infection progress. At 100 the part is "infected" for gameplay purposes. */
	private float infection;
	private BurnLevel burn = BurnLevel.NONE;
	private boolean bruised;
	private boolean laceration;
	private int gunshotWounds;
	private boolean internalBleeding;
	/** 0-100 local pain contribution from this part's injuries. */
	private float pain;

	public BodyPartData(float maxHp) {
		this.maxHp = maxHp;
		this.currentHp = maxHp;
	}

	public static BodyPartData full(BodyPart part) {
		return new BodyPartData(part.getBaseMaxHp());
	}

	// --- HP ---

	public float getCurrentHp() {
		return currentHp;
	}

	public float getMaxHp() {
		return maxHp;
	}

	public void setMaxHp(float maxHp) {
		this.maxHp = maxHp;
		this.currentHp = Math.min(this.currentHp, maxHp);
	}

	/** Applies damage, clamping at 0. Returns the amount actually absorbed. */
	public float damage(float amount) {
		if (amount <= 0) {
			return 0;
		}
		float before = currentHp;
		currentHp = Math.max(0, currentHp - amount);
		return before - currentHp;
	}

	public void heal(float amount) {
		if (amount <= 0) {
			return;
		}
		currentHp = Math.min(maxHp, currentHp + amount);
	}

	public boolean isDestroyed() {
		return currentHp <= 0;
	}

	public float getHpFraction() {
		return maxHp <= 0 ? 0 : currentHp / maxHp;
	}

	// --- Bleeding ---

	public BleedingLevel getBleeding() {
		return bleeding;
	}

	public void setBleeding(BleedingLevel bleeding) {
		this.bleeding = bleeding;
	}

	public void worsenBleeding() {
		this.bleeding = this.bleeding.worsen();
	}

	// --- Fracture ---

	public boolean isFractured() {
		return fractured;
	}

	public void setFractured(boolean fractured) {
		this.fractured = fractured;
	}

	// --- Infection ---

	public float getInfection() {
		return infection;
	}

	public void setInfection(float infection) {
		this.infection = Math.max(0, Math.min(100, infection));
	}

	public boolean isInfected() {
		return infection >= 100.0f;
	}

	// --- Burns ---

	public BurnLevel getBurn() {
		return burn;
	}

	public void setBurn(BurnLevel burn) {
		this.burn = burn;
	}

	// --- Bruise / Laceration / Gunshot / Internal bleeding ---

	public boolean isBruised() {
		return bruised;
	}

	public void setBruised(boolean bruised) {
		this.bruised = bruised;
	}

	public boolean hasLaceration() {
		return laceration;
	}

	public void setLaceration(boolean laceration) {
		this.laceration = laceration;
	}

	public int getGunshotWounds() {
		return gunshotWounds;
	}

	public void addGunshotWound() {
		this.gunshotWounds++;
	}

	public boolean hasInternalBleeding() {
		return internalBleeding;
	}

	public void setInternalBleeding(boolean internalBleeding) {
		this.internalBleeding = internalBleeding;
	}

	// --- Pain ---

	public float getPain() {
		return pain;
	}

	public void setPain(float pain) {
		this.pain = Math.max(0, Math.min(100, pain));
	}

	public void addPain(float amount) {
		setPain(this.pain + amount);
	}

	/** True if this part has no active injuries at all (used for the injuries menu / HUD icons). */
	public boolean isUninjured() {
		return currentHp >= maxHp && bleeding == BleedingLevel.NONE && !fractured && infection <= 0
				&& burn == BurnLevel.NONE && !bruised && !laceration && gunshotWounds == 0 && !internalBleeding;
	}

	// --- NBT ---

	public NbtCompound toNbt() {
		NbtCompound nbt = new NbtCompound();
		nbt.putFloat("currentHp", currentHp);
		nbt.putFloat("maxHp", maxHp);
		nbt.putString("bleeding", bleeding.name());
		nbt.putBoolean("fractured", fractured);
		nbt.putFloat("infection", infection);
		nbt.putString("burn", burn.name());
		nbt.putBoolean("bruised", bruised);
		nbt.putBoolean("laceration", laceration);
		nbt.putInt("gunshotWounds", gunshotWounds);
		nbt.putBoolean("internalBleeding", internalBleeding);
		nbt.putFloat("pain", pain);
		return nbt;
	}

	public static BodyPartData fromNbt(NbtCompound nbt) {
		BodyPartData data = new BodyPartData(nbt.getFloat("maxHp"));
		data.currentHp = nbt.getFloat("currentHp");
		data.bleeding = BleedingLevel.valueOf(nbt.getString("bleeding"));
		data.fractured = nbt.getBoolean("fractured");
		data.infection = nbt.getFloat("infection");
		data.burn = BurnLevel.valueOf(nbt.getString("burn"));
		data.bruised = nbt.getBoolean("bruised");
		data.laceration = nbt.getBoolean("laceration");
		data.gunshotWounds = nbt.getInt("gunshotWounds");
		data.internalBleeding = nbt.getBoolean("internalBleeding");
		data.pain = nbt.getFloat("pain");
		return data;
	}
}
