package com.casualtiesunknown.components;

/** Overall shock state, driven by the ShockSystem from blood loss, pain and burst damage. */
public enum ShockLevel {
	NONE,
	MILD,
	MODERATE,
	SEVERE;

	public boolean isInShock() {
		return this != NONE;
	}
}
