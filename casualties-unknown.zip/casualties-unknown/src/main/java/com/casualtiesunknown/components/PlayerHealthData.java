package com.casualtiesunknown.components;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;

import java.util.EnumMap;
import java.util.Map;

/**
 * The full custom-medical-system state for a single player. Attached to the
 * player via a Fabric data attachment (see ModAttachmentTypes) and persisted
 * automatically by Fabric across death/dimension-change/logout/server-restart
 * as configured on the attachment.
 *
 * <p>This object is server-authoritative: the server is the only side that
 * ever mutates it in response to game logic. The client receives read-only
 * snapshots via {@link com.casualtiesunknown.network.HealthSyncPayload}
 * and stores them in the client-side cache used purely for rendering the
 * HUD / Injuries Menu.
 */
public final class PlayerHealthData {

	public static final float MAX_BLOOD_ML = 5000.0f;
	public static final float NORMAL_BODY_TEMP_C = 37.0f;

	private final Map<BodyPart, BodyPartData> parts = new EnumMap<>(BodyPart.class);

	private float bloodMl = MAX_BLOOD_ML;
	private float exhaustion; // 0-100, separate from vanilla hunger
	private float hydration = 100.0f; // 0-100
	private float bloodSugar = 100.0f; // 0-100, nudged by Orange Juice
	private float temperatureC = NORMAL_BODY_TEMP_C;
	private ShockLevel shock = ShockLevel.NONE;
	private float shockMeter; // 0-100 internal accumulator driving ShockLevel
	private boolean collapsed; // true when the player can no longer act due to blood loss/shock

	/** True once created; used to distinguish "just attached" defaults from loaded data. */
	private boolean initialized;

	public PlayerHealthData() {
		for (BodyPart part : BodyPart.values()) {
			parts.put(part, BodyPartData.full(part));
		}
		this.initialized = true;
	}

	public static PlayerHealthData createDefault() {
		return new PlayerHealthData();
	}

	public BodyPartData part(BodyPart part) {
		return parts.get(part);
	}

	public Map<BodyPart, BodyPartData> allParts() {
		return parts;
	}

	// --- Blood ---

	public float getBloodMl() {
		return bloodMl;
	}

	public void setBloodMl(float bloodMl) {
		this.bloodMl = Math.max(0, Math.min(MAX_BLOOD_ML, bloodMl));
	}

	public void addBlood(float amount) {
		setBloodMl(this.bloodMl + amount);
	}

	public float getBloodFraction() {
		return bloodMl / MAX_BLOOD_ML;
	}

	// --- Exhaustion ---

	public float getExhaustion() {
		return exhaustion;
	}

	public void setExhaustion(float exhaustion) {
		this.exhaustion = Math.max(0, Math.min(100, exhaustion));
	}

	public void addExhaustion(float amount) {
		setExhaustion(this.exhaustion + amount);
	}

	// --- Hydration ---

	public float getHydration() {
		return hydration;
	}

	public void setHydration(float hydration) {
		this.hydration = Math.max(0, Math.min(100, hydration));
	}

	public void addHydration(float amount) {
		setHydration(this.hydration + amount);
	}

	// --- Blood sugar ---

	public float getBloodSugar() {
		return bloodSugar;
	}

	public void setBloodSugar(float bloodSugar) {
		this.bloodSugar = Math.max(0, Math.min(100, bloodSugar));
	}

	public void addBloodSugar(float amount) {
		setBloodSugar(this.bloodSugar + amount);
	}

	// --- Temperature ---

	public float getTemperatureC() {
		return temperatureC;
	}

	public void setTemperatureC(float temperatureC) {
		this.temperatureC = temperatureC;
	}

	// --- Shock ---

	public ShockLevel getShock() {
		return shock;
	}

	public void setShock(ShockLevel shock) {
		this.shock = shock;
	}

	public float getShockMeter() {
		return shockMeter;
	}

	public void setShockMeter(float shockMeter) {
		this.shockMeter = Math.max(0, Math.min(100, shockMeter));
	}

	public void addShockMeter(float amount) {
		setShockMeter(this.shockMeter + amount);
	}

	// --- Collapse ---

	public boolean isCollapsed() {
		return collapsed;
	}

	public void setCollapsed(boolean collapsed) {
		this.collapsed = collapsed;
	}

	// --- Aggregates ---

	/** Global pain 0-100, the max of local part pains plus a shock/blood-loss contribution. */
	public float getGlobalPain() {
		float max = 0;
		for (BodyPartData data : parts.values()) {
			max = Math.max(max, data.getPain());
		}
		float bloodPain = (1.0f - getBloodFraction()) * 30.0f;
		return Math.max(0, Math.min(100, max + bloodPain * 0.3f));
	}

	public boolean isBleedingAnywhere() {
		for (BodyPartData data : parts.values()) {
			if (data.getBleeding().isBleeding()) {
				return true;
			}
		}
		return false;
	}

	public BleedingLevel worstBleeding() {
		BleedingLevel worst = BleedingLevel.NONE;
		for (BodyPartData data : parts.values()) {
			if (data.getBleeding().ordinal() > worst.ordinal()) {
				worst = data.getBleeding();
			}
		}
		return worst;
	}

	public boolean isAnyFractured() {
		return parts.get(BodyPart.LEFT_ARM).isFractured() || parts.get(BodyPart.RIGHT_ARM).isFractured()
				|| parts.get(BodyPart.LEFT_LEG).isFractured() || parts.get(BodyPart.RIGHT_LEG).isFractured();
	}

	public boolean isLegFractured() {
		return parts.get(BodyPart.LEFT_LEG).isFractured() || parts.get(BodyPart.RIGHT_LEG).isFractured();
	}

	public boolean isArmFractured() {
		return parts.get(BodyPart.LEFT_ARM).isFractured() || parts.get(BodyPart.RIGHT_ARM).isFractured();
	}

	public boolean isAnyInfected() {
		for (BodyPartData data : parts.values()) {
			if (data.isInfected()) {
				return true;
			}
		}
		return false;
	}

	/** Overall condition, 0-100, a coarse combination of blood + worst-part HP. Used for the collapse/death checks. */
	public float getOverallConditionFraction() {
		float worstPartFraction = 1.0f;
		for (BodyPart part : new BodyPart[] {BodyPart.HEAD, BodyPart.TORSO}) {
			worstPartFraction = Math.min(worstPartFraction, parts.get(part).getHpFraction());
		}
		return Math.min(worstPartFraction, getBloodFraction());
	}

	public boolean isDead() {
		return parts.get(BodyPart.HEAD).isDestroyed() || parts.get(BodyPart.TORSO).isDestroyed() || bloodMl <= 0;
	}

	/** Resets everything to full health. Used on respawn when keepInventory-style config is off. */
	public void resetToFull() {
		for (BodyPart part : BodyPart.values()) {
			parts.put(part, BodyPartData.full(part));
		}
		bloodMl = MAX_BLOOD_ML;
		exhaustion = 0;
		hydration = 100;
		bloodSugar = 100;
		temperatureC = NORMAL_BODY_TEMP_C;
		shock = ShockLevel.NONE;
		shockMeter = 0;
		collapsed = false;
	}

	// --- NBT (both for persistence via the attachment, and reused for network sync) ---

	public NbtCompound toNbt() {
		NbtCompound nbt = new NbtCompound();
		NbtList partList = new NbtList();
		for (BodyPart part : BodyPart.values()) {
			NbtCompound partNbt = parts.get(part).toNbt();
			partNbt.putString("part", part.getKey());
			partList.add(partNbt);
		}
		nbt.put("parts", partList);
		nbt.putFloat("blood", bloodMl);
		nbt.putFloat("exhaustion", exhaustion);
		nbt.putFloat("hydration", hydration);
		nbt.putFloat("bloodSugar", bloodSugar);
		nbt.putFloat("temperature", temperatureC);
		nbt.putString("shock", shock.name());
		nbt.putFloat("shockMeter", shockMeter);
		nbt.putBoolean("collapsed", collapsed);
		return nbt;
	}

	public static PlayerHealthData fromNbt(NbtCompound nbt) {
		PlayerHealthData data = new PlayerHealthData();
		if (nbt.contains("parts", NbtElement.LIST_TYPE)) {
			NbtList partList = nbt.getList("parts", NbtElement.COMPOUND_TYPE);
			for (int i = 0; i < partList.size(); i++) {
				NbtCompound partNbt = partList.getCompound(i);
				BodyPart part = BodyPart.byKey(partNbt.getString("part"));
				data.parts.put(part, BodyPartData.fromNbt(partNbt));
			}
		}
		data.bloodMl = nbt.getFloat("blood");
		data.exhaustion = nbt.getFloat("exhaustion");
		data.hydration = nbt.getFloat("hydration");
		data.bloodSugar = nbt.getFloat("bloodSugar");
		data.temperatureC = nbt.contains("temperature") ? nbt.getFloat("temperature") : NORMAL_BODY_TEMP_C;
		data.shock = nbt.contains("shock") ? ShockLevel.valueOf(nbt.getString("shock")) : ShockLevel.NONE;
		data.shockMeter = nbt.getFloat("shockMeter");
		data.collapsed = nbt.getBoolean("collapsed");
		return data;
	}

	/** Deep copy, used by the client cache so render code never mutates the synced snapshot in place. */
	public PlayerHealthData copy() {
		return fromNbt(this.toNbt());
	}
}
