package com.casualtiesunknown.components;

/**
 * Severity of bleeding on a single body part. Each level drains blood volume
 * faster than the last (see PlayerHealthData for the actual rates).
 */
public enum BleedingLevel {
	NONE(0.0f),
	MINOR(2.0f),
	MODERATE(5.0f),
	SEVERE(10.0f),
	MASSIVE(18.0f);

	private final float bloodLossPerSecond;

	BleedingLevel(float bloodLossPerSecond) {
		this.bloodLossPerSecond = bloodLossPerSecond;
	}

	public float getBloodLossPerSecond() {
		return bloodLossPerSecond;
	}

	public boolean isBleeding() {
		return this != NONE;
	}

	/** Escalates one step, capping at MASSIVE. Used when a wounded part takes further damage. */
	public BleedingLevel worsen() {
		return switch (this) {
			case NONE -> MINOR;
			case MINOR -> MODERATE;
			case MODERATE -> SEVERE;
			case SEVERE, MASSIVE -> MASSIVE;
		};
	}

	/** Reduces one step, used by successful bandage treatment. */
	public BleedingLevel improve() {
		return switch (this) {
			case NONE, MINOR -> NONE;
			case MODERATE -> MINOR;
			case SEVERE -> MODERATE;
			case MASSIVE -> SEVERE;
		};
	}
}
