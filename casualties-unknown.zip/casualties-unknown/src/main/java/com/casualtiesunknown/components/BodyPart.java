package com.casualtiesunknown.components;

/**
 * The six independently-tracked body regions used by the custom health system.
 * Max HP values match the design spec: Head 100, Torso 150, each arm 100, each leg 100.
 */
public enum BodyPart {
	HEAD("head", 100.0f, 1.0f),
	TORSO("torso", 150.0f, 1.0f),
	LEFT_ARM("left_arm", 100.0f, 0.6f),
	RIGHT_ARM("right_arm", 100.0f, 0.6f),
	LEFT_LEG("left_leg", 100.0f, 0.8f),
	RIGHT_LEG("right_leg", 100.0f, 0.8f);

	/** Identifier used in NBT / network payloads and translation keys. */
	private final String key;
	/** Base max HP for this part. */
	private final float baseMaxHp;
	/**
	 * Relative "vitality weight" used when deciding how much a part's damage
	 * contributes to overall shock/pain/death checks. Head and torso wounds
	 * matter more than limb wounds.
	 */
	private final float vitalityWeight;

	BodyPart(String key, float baseMaxHp, float vitalityWeight) {
		this.key = key;
		this.baseMaxHp = baseMaxHp;
		this.vitalityWeight = vitalityWeight;
	}

	public String getKey() {
		return key;
	}

	public float getBaseMaxHp() {
		return baseMaxHp;
	}

	public float getVitalityWeight() {
		return vitalityWeight;
	}

	public boolean isArm() {
		return this == LEFT_ARM || this == RIGHT_ARM;
	}

	public boolean isLeg() {
		return this == LEFT_LEG || this == RIGHT_LEG;
	}

	public boolean isVital() {
		return this == HEAD || this == TORSO;
	}

	public static BodyPart byKey(String key) {
		for (BodyPart part : values()) {
			if (part.key.equals(key)) {
				return part;
			}
		}
		throw new IllegalArgumentException("Unknown body part key: " + key);
	}
}
