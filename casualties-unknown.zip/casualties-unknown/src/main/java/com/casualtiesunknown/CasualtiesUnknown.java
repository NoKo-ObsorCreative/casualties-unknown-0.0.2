package com.casualtiesunknown;

import com.casualtiesunknown.config.ModConfig;
import com.casualtiesunknown.events.DamageEventHandler;
import com.casualtiesunknown.events.PlayerConnectionHandler;
import com.casualtiesunknown.events.ServerTickHandler;
import com.casualtiesunknown.network.ModNetworking;
import com.casualtiesunknown.registry.ModAttachmentTypes;
import com.casualtiesunknown.registry.ModItemGroups;
import com.casualtiesunknown.registry.ModItems;
import com.casualtiesunknown.registry.ModSounds;
import com.casualtiesunknown.util.ModConstants;

import net.fabricmc.api.ModInitializer;

/**
 * Common entrypoint -- runs on both the client and the dedicated server.
 * Client-only setup (HUD, GUI, keybinds, dynamic lights) lives in
 * {@link com.casualtiesunknown.client.CasualtiesUnknownClient} instead.
 */
public final class CasualtiesUnknown implements ModInitializer {

	@Override
	public void onInitialize() {
		ModConstants.LOGGER.info("Initializing Casualties Unknown Health System");

		// Load config first since several registrations/handlers read defaults from it.
		ModConfig.get();

		// Registries
		ModSounds.register();
		ModItems.register();
		ModItemGroups.register();
		ModAttachmentTypes.register();

		// Networking (payload types must be registered identically on both sides)
		ModNetworking.registerPayloadTypes();
		ModNetworking.registerServerReceivers();

		// Server-side gameplay systems
		DamageEventHandler.register();
		ServerTickHandler.register();
		PlayerConnectionHandler.register();

		ModConstants.LOGGER.info("Casualties Unknown Health System initialized");
	}
}
