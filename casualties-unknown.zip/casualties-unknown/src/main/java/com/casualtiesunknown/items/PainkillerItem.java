package com.casualtiesunknown.items;

import com.casualtiesunknown.components.BodyPart;
import com.casualtiesunknown.components.PlayerHealthData;
import com.casualtiesunknown.medical.MedicalItem;

import net.minecraft.server.network.ServerPlayerEntity;

/** Reduces pain across the whole body temporarily. Does not heal HP or stop bleeding. */
public class PainkillerItem extends MedicalItem {

	public PainkillerItem(Settings settings) {
		super(settings);
	}

	@Override
	public int getUseDurationTicks() {
		return 20;
	}

	@Override
	public void applyTreatment(ServerPlayerEntity player, float quality) {
		PlayerHealthData data = dataOf(player);
		for (BodyPart part : BodyPart.values()) {
			data.part(part).addPain(-35.0f * quality);
		}
		playTreatmentSound(player);
		syncAndCheckDeath(player, data);
	}
}
