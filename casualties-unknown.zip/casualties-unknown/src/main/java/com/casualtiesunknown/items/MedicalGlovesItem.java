package com.casualtiesunknown.items;

import net.minecraft.item.Item;

/**
 * Not an active treatment item -- while worn/held in the offhand, this
 * passively reduces the chance of untreated wounds seeding an infection.
 * See {@link com.casualtiesunknown.effects.InfectionSystem} for where that
 * check happens.
 */
public class MedicalGlovesItem extends Item {

	/** Multiplier applied to infection seed chance while this item is in the offhand. */
	public static final float SEED_CHANCE_MULTIPLIER = 0.5f;

	public MedicalGlovesItem(Settings settings) {
		super(settings);
	}
}
