package com.casualtiesunknown.items;

import com.casualtiesunknown.components.BodyPart;
import com.casualtiesunknown.components.PlayerHealthData;
import com.casualtiesunknown.medical.MedicalItem;

import net.minecraft.server.network.ServerPlayerEntity;

/**
 * A fast-acting emergency shot: quick relief for pain and a small nudge
 * against infection, at the cost of a little extra exhaustion afterwards
 * (the adrenaline crash).
 */
public class SyringeItem extends MedicalItem {

	public SyringeItem(Settings settings) {
		super(settings);
	}

	@Override
	public int getUseDurationTicks() {
		return 15;
	}

	@Override
	public void applyTreatment(ServerPlayerEntity player, float quality) {
		PlayerHealthData data = dataOf(player);
		for (BodyPart part : BodyPart.values()) {
			var partData = data.part(part);
			partData.addPain(-20.0f * quality);
			partData.setInfection(partData.getInfection() - 10.0f * quality);
		}
		data.addExhaustion(8.0f);
		playTreatmentSound(player);
		syncAndCheckDeath(player, data);
	}
}
