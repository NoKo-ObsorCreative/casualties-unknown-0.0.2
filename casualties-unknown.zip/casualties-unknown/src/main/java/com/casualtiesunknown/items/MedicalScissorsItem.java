package com.casualtiesunknown.items;

import com.casualtiesunknown.components.BodyPart;
import com.casualtiesunknown.components.BodyPartData;
import com.casualtiesunknown.components.PlayerHealthData;
import com.casualtiesunknown.medical.MedicalItem;
import com.casualtiesunknown.medical.TreatmentTargets;

import net.minecraft.server.network.ServerPlayerEntity;

/**
 * A quick, reusable tool: eases one level of bleeding almost instantly, but
 * less effectively than an actual Bandage, and never consumed (it's a
 * tool, not a supply -- durability wear is left as a straightforward
 * extension point, see docs/DEVELOPER.md).
 */
public class MedicalScissorsItem extends MedicalItem {

	public MedicalScissorsItem(Settings settings) {
		super(settings);
	}

	@Override
	public int getUseDurationTicks() {
		return 15;
	}

	@Override
	public boolean isConsumable() {
		return false;
	}

	@Override
	public void applyTreatment(ServerPlayerEntity player, float quality) {
		PlayerHealthData data = dataOf(player);
		BodyPart target = TreatmentTargets.resolve(player.getUuid(), data, TreatmentTargets::autoPickBleeding);
		BodyPartData partData = data.part(target);
		partData.setBleeding(partData.getBleeding().improve());
		partData.addPain(-2.0f);
		playTreatmentSound(player);
		syncAndCheckDeath(player, data);
	}
}
