package com.casualtiesunknown.items;

import com.casualtiesunknown.components.BodyPart;
import com.casualtiesunknown.components.BodyPartData;
import com.casualtiesunknown.components.PlayerHealthData;
import com.casualtiesunknown.medical.MedicalItem;

import net.minecraft.server.network.ServerPlayerEntity;

/** Reduces infection progress on whichever part is most infected/at risk. */
public class DisinfectantItem extends MedicalItem {

	public DisinfectantItem(Settings settings) {
		super(settings);
	}

	@Override
	public int getUseDurationTicks() {
		return 30;
	}

	@Override
	public void applyTreatment(ServerPlayerEntity player, float quality) {
		PlayerHealthData data = dataOf(player);
		BodyPart worst = com.casualtiesunknown.medical.TreatmentTargets.resolve(player.getUuid(), data, this::mostAtRisk);
		BodyPartData partData = data.part(worst);
		partData.setInfection(partData.getInfection() - 60.0f * quality);
		playTreatmentSound(player);
		syncAndCheckDeath(player, data);
	}

	private BodyPart mostAtRisk(PlayerHealthData data) {
		BodyPart best = BodyPart.TORSO;
		float bestInfection = -1;
		for (BodyPart part : BodyPart.values()) {
			float infection = data.part(part).getInfection();
			if (infection > bestInfection) {
				best = part;
				bestInfection = infection;
			}
		}
		return best;
	}
}
