package com.casualtiesunknown.items;

import com.casualtiesunknown.components.PlayerHealthData;
import com.casualtiesunknown.medical.MedicalItem;

import net.minecraft.server.network.ServerPlayerEntity;

/**
 * Restores hydration, a small amount of exhaustion, and a little blood
 * sugar. Deliberately never touches HP, per the spec ("Cannot restore HP").
 */
public class OrangeJuiceItem extends MedicalItem {

	public OrangeJuiceItem(Settings settings) {
		super(settings);
	}

	@Override
	public int getUseDurationTicks() {
		return 20;
	}

	@Override
	public void applyTreatment(ServerPlayerEntity player, float quality) {
		PlayerHealthData data = dataOf(player);
		data.addHydration(20.0f * quality);
		data.addExhaustion(-10.0f * quality);
		data.addBloodSugar(15.0f * quality);
		playTreatmentSound(player);
		syncAndCheckDeath(player, data);
	}
}
