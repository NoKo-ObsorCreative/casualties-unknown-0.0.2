package com.casualtiesunknown.items;

import com.casualtiesunknown.components.BleedingLevel;
import com.casualtiesunknown.components.BodyPart;
import com.casualtiesunknown.components.BodyPartData;
import com.casualtiesunknown.components.PlayerHealthData;
import com.casualtiesunknown.medical.MedicalItem;
import com.casualtiesunknown.medical.TreatmentTargets;

import net.minecraft.server.network.ServerPlayerEntity;

/**
 * Immediately halts bleeding on an arm or leg -- more reliable than a
 * Bandage for severe/massive bleeds, at the cost of some extra pain from
 * restricted circulation while it's on.
 */
public class TourniquetItem extends MedicalItem {

	public TourniquetItem(Settings settings) {
		super(settings);
	}

	@Override
	public int getUseDurationTicks() {
		return 25;
	}

	@Override
	public void applyTreatment(ServerPlayerEntity player, float quality) {
		PlayerHealthData data = dataOf(player);
		BodyPart target = TreatmentTargets.resolve(player.getUuid(), data, this::worstLimbBleed);
		BodyPartData partData = data.part(target);

		if (target.isArm() || target.isLeg()) {
			partData.setBleeding(BleedingLevel.NONE);
			partData.addPain(6.0f);
		}
		playTreatmentSound(player);
		syncAndCheckDeath(player, data);
	}

	private BodyPart worstLimbBleed(PlayerHealthData data) {
		BodyPart best = BodyPart.LEFT_ARM;
		BleedingLevel bestLevel = BleedingLevel.NONE;
		for (BodyPart part : new BodyPart[] {BodyPart.LEFT_ARM, BodyPart.RIGHT_ARM, BodyPart.LEFT_LEG, BodyPart.RIGHT_LEG}) {
			BleedingLevel level = data.part(part).getBleeding();
			if (level.ordinal() > bestLevel.ordinal()) {
				best = part;
				bestLevel = level;
			}
		}
		return best;
	}
}
