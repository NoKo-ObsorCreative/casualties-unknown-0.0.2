package com.casualtiesunknown.items;

import com.casualtiesunknown.components.BodyPart;
import com.casualtiesunknown.components.PlayerHealthData;
import com.casualtiesunknown.medical.MedicalItem;

import net.minecraft.server.network.ServerPlayerEntity;

/** Strong, body-wide infection treatment -- the reliable cure once an infection has already taken hold. */
public class AntibioticsItem extends MedicalItem {

	public AntibioticsItem(Settings settings) {
		super(settings);
	}

	@Override
	public int getUseDurationTicks() {
		return 40;
	}

	@Override
	public void applyTreatment(ServerPlayerEntity player, float quality) {
		PlayerHealthData data = dataOf(player);
		for (BodyPart part : BodyPart.values()) {
			var partData = data.part(part);
			partData.setInfection(partData.getInfection() - 100.0f * quality);
		}
		data.setTemperatureC(Math.max(PlayerHealthData.NORMAL_BODY_TEMP_C, data.getTemperatureC() - 0.5f));
		playTreatmentSound(player);
		syncAndCheckDeath(player, data);
	}
}
