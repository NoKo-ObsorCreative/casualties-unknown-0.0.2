package com.casualtiesunknown.items;

import com.casualtiesunknown.components.PlayerHealthData;
import com.casualtiesunknown.medical.MedicalItem;

import net.minecraft.server.network.ServerPlayerEntity;

/**
 * A dedicated Casualties Unknown water bottle for topping up hydration.
 * Kept as its own item (rather than reusing vanilla's potion-based Water
 * Bottle) to sidestep the vanilla potion/brewing item-component machinery
 * entirely -- see docs/DEVELOPER.md for why.
 */
public class WaterBottleItem extends MedicalItem {

	public WaterBottleItem(Settings settings) {
		super(settings);
	}

	@Override
	public int getUseDurationTicks() {
		return 20;
	}

	@Override
	public void applyTreatment(ServerPlayerEntity player, float quality) {
		PlayerHealthData data = dataOf(player);
		data.addHydration(35.0f * quality);
		playTreatmentSound(player);
		syncAndCheckDeath(player, data);
	}
}
