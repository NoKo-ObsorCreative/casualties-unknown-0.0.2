package com.casualtiesunknown.network;

import com.casualtiesunknown.components.BodyPart;
import com.casualtiesunknown.util.ModConstants;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/**
 * Client -> server. Sent when the player clicks "Focus" on a body part in
 * the Injuries Menu. The server remembers this as the player's preferred
 * treatment target (see com.casualtiesunknown.medical.TreatmentTargets) so
 * the next bandage/splint/etc. use is applied to that part instead of the
 * auto-picked worst wound.
 */
public record SelectTreatmentTargetPayload(BodyPart part) implements CustomPayload {

	public static final CustomPayload.Id<SelectTreatmentTargetPayload> ID =
			new CustomPayload.Id<>(ModConstants.id("select_treatment_target"));

	public static final PacketCodec<RegistryByteBuf, SelectTreatmentTargetPayload> CODEC = PacketCodec.tuple(
			PacketCodecs.STRING.xmap(BodyPart::byKey, BodyPart::getKey), SelectTreatmentTargetPayload::part,
			SelectTreatmentTargetPayload::new
	);

	@Override
	public Id<? extends CustomPayload> getId() {
		return ID;
	}
}
